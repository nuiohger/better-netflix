 class NetflixSelectors {
    public static get videoBitrateClass() {
        return "player-streams";
    }
}

export default NetflixSelectors;
