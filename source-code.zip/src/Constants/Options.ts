const defaultKeys = {
    zoomIn: "+",
    zoomOut: "-",
    resetZoom: ",",
    fullZoom: ".",
    disableMouse: "d",
    enableMouse: "e",
    timeElapsed: true,
    toggleStatistics: "q",
    selectHighestBitrate: true,
    menuOnTop: true,
    volumeMouseWheel: true
};

export default defaultKeys;
